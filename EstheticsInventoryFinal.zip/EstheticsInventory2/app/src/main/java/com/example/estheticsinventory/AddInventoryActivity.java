package com.example.estheticsinventory;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddInventoryActivity extends AppCompatActivity {

    private EditText productNameInput;
    private EditText categoryInput;
    private EditText quantityInput;
    private EditText descriptionInput;
    private DatabaseHelper databaseHelper;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Use existing Add Inventory layout
        setContentView(R.layout.activity_add_inventory);

        databaseHelper = new DatabaseHelper(this);
        userId = getIntent().getLongExtra("userId", -1);

        if (userId < 1) {
            finish();
            return;
        }

        //Connect input fields
        productNameInput = findViewById(R.id.editTextText2);
        categoryInput = findViewById(R.id.editTextText3);
        quantityInput = findViewById(R.id.editTextNumber);
        descriptionInput = findViewById(R.id.editTextText5);

        //Connect add button
        Button saveButton = findViewById(R.id.button5);
        Button cancelButton = findViewById(R.id.button6);

        //Replace sample text with hints
        productNameInput.setText("");
        productNameInput.setHint("Enter product name");

        categoryInput.setText("");
        categoryInput.setHint("Enter category");

        quantityInput.setHint("Enter quantity");

        descriptionInput.setText("");
        descriptionInput.setHint("Enter description");

        saveButton.setOnClickListener(view -> saveProduct());

        cancelButton.setOnClickListener(view -> finish());
    }

    private void saveProduct() {
        String productName = productNameInput.getText()
                .toString();

        String category = categoryInput.getText()
                .toString();

        String quantityText = quantityInput.getText()
                .toString().trim();

        String description = descriptionInput.getText()
                .toString();

        //Validate required information
        if (productName.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a product name and quantity",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            Toast.makeText(this,
                    "Please enter a valid quantity",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (quantity <= 0) {
            Toast.makeText(this,
                    "Please enter a positive quantity. Cannot be negative",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        //Save new product in SQLite
        long result = databaseHelper.addInventory(
                userId,
                productName,
                category,
                quantity,
                description
        );

        if (result > 0) {

            //Check for low stock after saving product
            SmsAlertHelper.checkLowStock(
                    this,
                    userId,
                    productName,
                    quantity
            );

            Toast.makeText(
                    this,
                    "User ID: " + userId
                            + " | Product: " + productName
                            + " | Quantity: " + quantity
                            + " | Result: " + result,
                    Toast.LENGTH_LONG
            ).show();

            if (result > 0) {
                Toast.makeText(this,
                        "Product added successfully!",
                        Toast.LENGTH_SHORT).show();
                finish();

            } else {
                Toast.makeText(this,
                        "Product could not be added. Try again.",
                        Toast.LENGTH_LONG).show();


            }
        }
    }
}

