package com.example.estheticsinventory;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class SmsAlertHelper {

    //Notify user when product hah 5 or lower in stock
    private static final int LOW_STOCK_THRESHOLD = 5;

    public static void checkLowStock(
            Context context,
            long userId,
            String productName,
            int quantity) {

        Log.d("SmsAlertHelper",
                "Low-stock check started: "
                        + productName
                        + ", quantity: "
                        + quantity);

        if (quantity > LOW_STOCK_THRESHOLD || quantity < 0) {
            return;}

        //Retrieve user's SMS notification preferences
        SharedPreferences preferences =
                context.getSharedPreferences(
                        "sms_settings",
                        Context.MODE_PRIVATE
                );

        boolean smsEnabled = preferences.getBoolean(
                "enabled_" + userId,
                false
        );

        String phone = preferences.getString(
                "phone_" + userId, "");

        Log.d(
                "SmsAlertHelper",
                "SMS enabled: " + smsEnabled + smsEnabled
                        + ", Phone saved: " + !phone.isEmpty()
        );

    if (!smsEnabled || phone.isEmpty()) {
        return;
    }

    //Do not send messages if notifications are disabled
    if (ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.SEND_SMS)
        !=PackageManager.PERMISSION_GRANTED)
    {
        return;
    }

    //Create low-inventory message
    String message =
            "Esthetics Inventory Alert: " +
                    productName + " is low in stock. Only " +
                    quantity;

    try

    {
        //Send SMS notification
        SmsManager smsManager = SmsManager.getDefault();

        smsManager.sendTextMessage(
                phone,
                null,
                message,
                null,
                null
        );

        Log.d("SmsAlertHelper", "SMS send requested");

    } catch(
    Exception exception)

    {
        Log.e("SmsAlertHelper", "SMS send failed", exception);
    }
}
}

