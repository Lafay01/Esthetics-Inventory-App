package com.example.estheticsinventory;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Initialize SQLite database
        databaseHelper = new DatabaseHelper(this);

        //Connect username and password input
        usernameInput = findViewById(R.id.editTextText);
        passwordInput = findViewById(R.id.editTextTextPassword);

        //Connect login button
        Button loginButton = findViewById(R.id.button);
        Button createAccountButton = findViewById(R.id.button2);

        //Add password hint
        passwordInput.setHint("Enter password");

        //Create account button
        loginButton.setOnClickListener(view -> loginUser());
        createAccountButton.setOnClickListener(view -> createAccount());

    }

    //Register new user in SQLite database
    private void createAccount() {
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 8) {
            Toast.makeText(this,
                    "Password must be at least 8 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.registerUser(username, password);

        if (success) {
            Toast.makeText(this,
                    "Account created successfully. Please log in.",
                    Toast.LENGTH_SHORT).show();

            passwordInput.setText("");

        } else {
            Toast.makeText(this,
                    "Username already exists or registration failed. Try again.",
                    Toast.LENGTH_LONG).show();
        }
    }

    //Validate user login
    private void loginUser() {

        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this,
                    "Please enter a username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        long userId = databaseHelper.loginUser(username, password);

        if (userId > 0) {

            Toast.makeText(this,
                    "Login successful!",
                    Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(
                    MainActivity.this,
                    InventoryActivity.class
            );

            intent.putExtra("userId", userId);
            startActivity(intent);
            finish();

        }
    }
}