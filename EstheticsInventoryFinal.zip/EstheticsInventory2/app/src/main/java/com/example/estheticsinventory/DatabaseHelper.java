package com.example.estheticsinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
public class DatabaseHelper  extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EstheticsInventory.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    private static final int HASH_ITERATIONS = 120000;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Store registered app users
        db.execSQL(
                "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE," +
                "password_hash TEXT NOT NULL, " +
                "password_salt TEXT NOT NULL)"
        );

        //Store inventory items
        db.execSQL(
                "CREATE TABLE inventory (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "user_id INTEGER NOT NULL, " +
                    "product_name TEXT NOT NULL, " +
                    "category TEXT, " +
                    "quantity INTEGER NOT NULL DEFAULT 0, " +
                    "product_description TEXT, " +
                    "FOREIGN KEY (user_id) REFERENCES users(id))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {
        //Future database upgrades will be placed here
        //Do not delete user data during upgrades
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    // Generate a salted password hash.
    private String hashPassword(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(),
                salt,
                HASH_ITERATIONS,
                256
        );

        try {
            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance(
                            "PBKDF2WithHmacSHA256"
                    );

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.encodeToString(
                    hash,
                    Base64.NO_WRAP
            );

        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Unable to hash password",
                    exception
            );
        } finally {
            spec.clearPassword();
        }
    }

    // Create a new user account.
    public boolean registerUser(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.length() < 8) {
            return false;
        }

        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        ContentValues values = new ContentValues();

        values.put("username", username.trim());
        values.put("password_hash", hashPassword(password, salt));
        values.put("password_salt",
                Base64.encodeToString(salt, Base64.NO_WRAP));

        long result = getWritableDatabase().insertWithOnConflict(
                TABLE_USERS,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );

        return result != -1;
    }

    // Verify a username and password.
    // Returns the user's ID, or -1 if login fails.
    public long loginUser(String username, String password) {

        if (username == null || password == null) {
            return -1;
        }

        Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{"id", "password_hash", "password_salt"},
                "username = ?",
                new String[]{username.trim()},
                null,
                null,
                null
        );

        try {
            if (!cursor.moveToFirst()) {
                return -1;
            }

            long userId = cursor.getLong(0);
            String storedHash = cursor.getString(1);
            String storedSalt = cursor.getString(2);

            byte[] salt = Base64.decode(
                    storedSalt,
                    Base64.NO_WRAP
            );

            byte[] expected = Base64.decode(
                    storedHash,
                    Base64.NO_WRAP
            );

            byte[] actual = Base64.decode(
                    hashPassword(password, salt),
                    Base64.NO_WRAP
            );

            if (MessageDigest.isEqual(expected, actual)) {
                return userId;
            }

            return -1;

        } finally {
            cursor.close();
        }
    }

    // Add a product to the logged-in user's inventory.
    public long addInventory(long userId,
                             String productName,
                             String category,
                             int quantity,
                             String product_description) {

        if (userId < 1 || productName == null
                || productName.trim().isEmpty()
                || quantity < 0) {
            return -1;
        }

        ContentValues values = new ContentValues();

        values.put("user_id", userId);
        values.put("product_name", productName.trim());
        values.put("category", category);
        values.put("quantity", quantity);
        values.put("product_description", product_description);

        return getWritableDatabase().insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    // Retrieve all inventory items belonging to a user.
    public Cursor getAllInventory(long userId) {

        return getReadableDatabase().query(
                TABLE_INVENTORY,
                null,
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "product_name ASC"
        );
    }

    // Retrieve one inventory item for editing.
    public Cursor getInventoryItem(long userId, long itemId) {

        return getReadableDatabase().query(
                TABLE_INVENTORY,
                null,
                "user_id = ? AND id = ?",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(itemId)
                },
                null,
                null,
                null
        );
    }

    // Update an existing inventory product.
    public boolean updateInventory(long userId,
                                   long itemId,
                                   String productName,
                                   String category,
                                   int quantity,
                                   String product_description) {

        if (userId < 1 || itemId < 1
                || productName == null
                || productName.trim().isEmpty()
                || quantity < 0) {
            return false;
        }

        ContentValues values = new ContentValues();

        values.put("product_name", productName.trim());
        values.put("category", category);
        values.put("quantity", quantity);
        values.put("product_description", product_description);

        int rowsUpdated = getWritableDatabase().update(
                TABLE_INVENTORY,
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );

        return rowsUpdated > 0;
    }

    // Delete one inventory product.
    public boolean deleteInventory(long userId, long itemId) {

        int rowsDeleted = getWritableDatabase().delete(
                TABLE_INVENTORY,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );

        return rowsDeleted > 0;
    }
}
