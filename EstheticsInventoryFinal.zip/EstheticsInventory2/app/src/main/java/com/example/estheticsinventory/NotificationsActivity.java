package com.example.estheticsinventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationsActivity extends AppCompatActivity {

    private EditText phoneInput;
    private TextView notificationStatus;
    private long userId;

    private final ActivityResultLauncher<String> smsNotificationLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            saveSettings();
                            Toast.makeText(this,
                                    "SMS alerts enabled",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            setSmsEnabled(false);
                            Toast.makeText(this,
                                    "SMS denied. Inventory still works.",
                                    Toast.LENGTH_LONG).show();
                        }
                        updatePermissionStatus();
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        userId = getIntent().getLongExtra("userId", -1);

        if (userId < 1) {
            finish();
            return;
        }

        phoneInput = findViewById(R.id.editTextPhone);
        notificationStatus = findViewById(R.id.textView8);

        Button enableButton = findViewById(R.id.button7);
        Button notNowButton = findViewById(R.id.button8);

        //Back button returns to inventory
        Button backButton = findViewById(R.id.buttonBackToInventory);

        backButton.setOnClickListener(view -> {
            finish();
        });

        SharedPreferences preferences =
                getSharedPreferences("sms_settings", MODE_PRIVATE);

        phoneInput.setText(preferences.getString(
                "phone_" + userId, ""));

        enableButton.setOnClickListener(view -> enableSms());

        notNowButton.setOnClickListener(view -> {
            setSmsEnabled(false);
            finish();
        });

        updatePermissionStatus();
    }

    private void enableSms() {
        String phone = phoneInput.getText().toString().trim();

        // Require a reasonable phone number before enabling alerts.
        String digits = phone.replaceAll("[^0-9]", "");

        if (digits.length() < 10 || digits.length() > 15) {
            Toast.makeText(this,
                    "Enter a valid phone number",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            saveSettings();
            updatePermissionStatus();
        } else {
            smsNotificationLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void saveSettings() {
        getSharedPreferences("sms_settings", MODE_PRIVATE)
                .edit()
                .putString("phone_" + userId,
                        phoneInput.getText().toString().trim())
                .putBoolean("enabled_" + userId, true)
                .apply();
    }

    private void setSmsEnabled(boolean enabled) {
        getSharedPreferences("sms_settings", MODE_PRIVATE)
                .edit()
                .putBoolean("enabled_" + userId, enabled)
                .apply();
    }

    private void updatePermissionStatus() {
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        boolean enabled = getSharedPreferences(
                "sms_settings", MODE_PRIVATE)
                .getBoolean("enabled_" + userId, false);

        notificationStatus.setText(
                granted && enabled
                        ? "SMS alerts: Enabled"
                        : "SMS alerts: Disabled"
        );
    }
}
