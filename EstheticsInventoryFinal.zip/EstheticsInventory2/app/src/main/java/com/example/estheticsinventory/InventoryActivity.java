package com.example.estheticsinventory;

import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.text.InputType;
import android.content.res.ColorStateList;
import android.graphics.Color;

import androidx.appcompat.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
public class InventoryActivity extends AppCompatActivity {

    private long userId;
    private DatabaseHelper databaseHelper;
    private TableLayout inventoryTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Display inventory layout
        setContentView(R.layout.activity_inventory);

        //Retrieve user ID from intent
        userId = getIntent().getLongExtra("userId", -1);

        if (userId < 1) {
            finish();
            return;
        }

        // Connect to the SQLite database.
        databaseHelper = new DatabaseHelper(this);

// Find the existing inventory table in the XML layout.
        ViewGroup root = (ViewGroup)
                findViewById(R.id.gridInventory).getParent();

        inventoryTable = (TableLayout) root.getChildAt(1);

// Connect the Add Product button.
        Button addProductButton = findViewById(R.id.button3);

        addProductButton.setOnClickListener(view -> {

            //Confirm button responds to clicks
            Toast.makeText(this,
                    "Add Product",
                    Toast.LENGTH_SHORT
            ).show();


            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddInventoryActivity.class
            );

            intent.putExtra("userId", userId);

            startActivity(intent);
        });

        // Connect the Notification Settings button.
        Button notificationsButton = findViewById(R.id.button4);

        notificationsButton.setOnClickListener(view -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationsActivity.class
            );

            //Pass current user's ID to notifications activity
            intent.putExtra("userId", userId);

            startActivity(intent);
        });


// Load inventory records.
        displayInventory();
    }

        // Create a text cell for the inventory table.
        private TextView createCell(String text) {

            TextView cell = new TextView(this);

            cell.setText(text);
            cell.setTextColor(0xFF243B55);
            cell.setTextSize(14);
            cell.setPadding(8, 12, 8, 12);

            return cell;
        }

        // Create a row for each inventory product.
        private void addProductRow(long itemId,
        String name,
        String category,
        int quantity,
        String description) {

            TableRow row = new TableRow(this);

            row.addView(createCell(name));
            row.addView(createCell(String.valueOf(quantity)));

            TextView editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setTextColor(Color.BLUE);
            editButton.setTextSize(11);
            editButton.setPadding(8, 12, 8, 12);
            editButton.setClickable(true);;
            row.addView(editButton);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextColor(Color.RED);
            deleteButton.setTextSize(11);
            deleteButton.setPadding(8, 12, 8, 12);
            deleteButton.setClickable(true);
            row.addView(deleteButton);

            // Edit product quantity.
            editButton.setOnClickListener(view -> {
                        editQuantity(
                                itemId,
                                name,
                                category,
                                quantity,
                                description);
                    });

            // Delete product.
            deleteButton.setOnClickListener(view -> {
                confirmDelete(itemId, name);
            });

            inventoryTable.addView(row);
        }

        // Edit the quantity of an inventory product.
        private void editQuantity(long itemId,
        String name,
        String category,
        int currentQuantity,
        String description) {

            EditText input = new EditText(this);

            input.setInputType(InputType.TYPE_CLASS_NUMBER);
            input.setText(String.valueOf(currentQuantity));

            new AlertDialog.Builder(this)
                    .setTitle("Edit Quantity: " + name)
                    .setView(input)
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Save", (dialog, which) -> {

                        try {
                            int newQuantity = Integer.parseInt(
                                    input.getText().toString().trim());

                            boolean updated = databaseHelper.updateInventory(
                                    userId,
                                    itemId,
                                    name,
                                    category,
                                    newQuantity,
                                    description
                            );

                            if (updated) {
                                displayInventory();

                                //Check updated stock
                                SmsAlertHelper.checkLowStock(
                                        this,
                                        userId,
                                        name,
                                        newQuantity
                                );


                                Toast.makeText(this,
                                        "Quantity updated",
                                        Toast.LENGTH_SHORT).show();
                            }

                        } catch (NumberFormatException exception) {
                            Toast.makeText(this,
                                    "Enter a valid quantity",
                                    Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        }

// Confirm before deleting a product.
        private void confirmDelete(long itemId, String name) {

            new AlertDialog.Builder(this)
                    .setTitle("Delete Product?")
                    .setMessage("Remove " + name + " from inventory?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete", (dialog, which) -> {

                        boolean deleted = databaseHelper.deleteInventory(
                                userId, itemId);

                        if (deleted) {
                            displayInventory();

                            Toast.makeText(this,
                                    "Product deleted",
                                    Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();
        }

        // Display saved products from SQLite.
        private void displayInventory() {

            inventoryTable.removeAllViews();

            // Create table headings.
            TableRow headerRow = new TableRow(this);

            headerRow.addView(createCell("Product"));
            headerRow.addView(createCell("Qty"));
            headerRow.addView(createCell("Edit"));
            headerRow.addView(createCell("Delete"));

            inventoryTable.addView(headerRow);

            // Read saved inventory records.
            try (Cursor cursor = databaseHelper.getAllInventory(userId)) {

                while (cursor.moveToNext()) {

                    long itemId = cursor.getLong(
                            cursor.getColumnIndexOrThrow("id"));

                    String name = cursor.getString(
                            cursor.getColumnIndexOrThrow("product_name"));

                    String category = cursor.getString(
                            cursor.getColumnIndexOrThrow("category"));

                    int quantity = cursor.getInt(
                            cursor.getColumnIndexOrThrow("quantity"));

                    String description = cursor.getString(
                            cursor.getColumnIndexOrThrow("product_description"));

                    addProductRow(itemId, name, category, quantity, description);
                }
            }
        }
@Override
protected void onResume() {
    super.onResume();

    if (inventoryTable != null) {
    displayInventory();
                    }
                }
            }
